package org.example;

public class Arreglos {
    public static void main(String args[]){
        int notas;
        int[] notasArreglo = {12,14,16};
        for(int x=0;x<notasArreglo.length;x++) {

        }
        for (Integer obj: notasArreglo){
            System.out.println(obj);
        }
    }
}
