package org.example;

import java.sql.SQLOutput;
import java.util.*; //trucaso

public class arreglosLista {
    public static  void main(String args[]){
        List<String> objNombres = new ArrayList<>();
        objNombres.add("Eriver");
        objNombres.add("Ray");
        objNombres.add("Adrian");

        Iterator<String>ObjIterator = objNombres.iterator();


        for(String c: objNombres){
            System.out.println(c);
        }

        while (ObjIterator.hasNext()){
            System.out.println(ObjIterator.next());
        }
    }}
/*
        List<String> objNombresLinked = new LinkedList<>();
        objNombresLinked.add("Eriver");
        objNombresLinked.add("Ray");
        objNombresLinked.add("Adrian");

        System.out.println(objNombresLinked);

        Set<String> objNombresSet = new HashSet<String>();
        objNombresSet.add("Eriver");
        objNombresSet.add("Ray");
        objNombresSet.add("Adrian");
        System.out.println(objNombresSet);


        Persona p1 = new Persona("Eriver", "Martinez", 25);
        Persona p2 = new Persona("Vitor", "Martin", 28);
        Persona p3 = new Persona("Donato", "Martir", 26);
        //1º
        List<Persona> list = Arrays.asList(p1,p2,p3);
        for (Persona objPer:list) {
            System.out.println(objPer.getApellidos());

 */












