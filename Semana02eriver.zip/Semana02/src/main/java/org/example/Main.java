package org.example;

public class Main {
    public static void main(String[] args) {
       /*
       for (int y=1;y<=6;y++){
        System.out.println(y*2);

        //While (condicion)
        int z=1;
        while (z<=12){
            System.out.println(z);
            z++;
            */
        double valor = Math.round(88.3546*100.0)/100.0;
        System.out.println(valor);


    }


}