package org.example;

public class Cliente {
    public static void main(String args[]){
        mensajeImpl objImpl = new mensajeImpl();
        objImpl.saludar( "usando interfaces");
    }

}
