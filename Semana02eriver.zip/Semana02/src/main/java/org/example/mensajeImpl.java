package org.example;

public class mensajeImpl implements Mensaje{
    @Override //dejamos asi el profe dice
    public void saludar(String msg) {
        System.out.println(msg);
    }

    @Override //metodo a modificar
    public int sumar(int n1, int n2) {
        return 0;
    }
}
