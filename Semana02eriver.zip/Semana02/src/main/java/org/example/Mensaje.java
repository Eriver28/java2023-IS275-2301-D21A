package org.example;

public interface Mensaje {
    public void saludar(String msg);
    public int sumar(int n1,int n2);
}
