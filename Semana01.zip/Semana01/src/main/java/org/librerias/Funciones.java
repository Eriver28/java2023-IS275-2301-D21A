package org.librerias;

public class Funciones {

    private  String saludar;
    public Funciones(String saludar) {
        this.saludar = saludar;
    }

    public void  saludar() {
        System.out.println(this.saludar);
    }
}
