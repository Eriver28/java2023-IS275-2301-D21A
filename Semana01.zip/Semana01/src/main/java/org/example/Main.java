package org.example;

//import org.librerias.Funciones;
import org.librerias.*;

public class Main {
    public static void main(String[] args) {
       // System.out.println("Clase de semana 1 Java");
        Alumno objAlumno01 = new Alumno(1, "Jimmy", 12, 10, 14);
        Alumno objAlumno02 = new Alumno(2, "Ray", 14, 18, 20);
        Alumno objAlumno03 = new Alumno(3, "Adrian", 14, 13, 14);
        Alumno objAlumno04 = new Alumno(5, "Eriver", 20, 20, 10);
        Alumno objAlumno = new Alumno();

        //Llamar al metodo de la clase alumno
        objAlumno01.mensaje();
        objAlumno02.mensajeParametro("hola");
        objAlumno03.mensajeParametro("pipipipipi");
        objAlumno04.mensajeParametro("metemetugaaaa");

        //Sale nombre Eriver
        objAlumno04.mensajeAtributo();
        objAlumno04.setNombres("Eriver Martinez");
        objAlumno04.mensajeAtributo();

        objAlumno03.mensajeAtributo();
        objAlumno03.setNombres("Adrian Zarate");
        objAlumno03.mensajeAtributo();

        objAlumno.mensajeAtributo();
        objAlumno.setNombres("Makanaki");
        objAlumno.mensajeAtributo();

        //llama al mtdo promedio
        double promedio=objAlumno04.promedio();
        objAlumno04.mensajeParametro(String.valueOf(promedio));

        //llamar a la clase funciones

        Funciones objFunciones = new Funciones("perry");
        objFunciones.saludar();

    }

}