package org.example;

public class Alumno {
    //crearemos la clase


    private int codigo;
    private String nombres;
    private  int nota1;

    //Atributo es unico y privado
    public   int nota2;
    private  int nota3;

    public Alumno(int codigo, String nombres, int nota1, int nota2, int nota3) {
        this.codigo = codigo;
        this.nombres = nombres;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
    }

    public void mensaje() {
        System.out.println("Hola soy de la clase alummno");

    }

    public void mensajeParametro(String msg){
        System.out.println(msg);
    }
    public void mensajeAtributo(){
        System.out.println(this.nombres);
    }
    public Alumno(){

    }
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    //calcular promedio

    public double promedio (){
        double resultado=0;
        resultado = (this.nota1 + this.nota2 + this.nota3)/3;
        return resultado;
    }

}
